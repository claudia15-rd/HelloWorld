package com.Producto2.cliente;

public class ClienteNotFoundException extends Throwable {
    public ClienteNotFoundException(String message) {
        super(message);
    }
}
