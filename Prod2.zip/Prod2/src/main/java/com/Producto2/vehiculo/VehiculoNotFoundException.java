package com.Producto2.vehiculo;

public class VehiculoNotFoundException extends Throwable {
    public VehiculoNotFoundException (String message){
        super(message);
    }

}
